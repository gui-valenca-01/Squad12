/* Service Worker — toda a interface e o vocabulário são cacheados após primeira visita com conexão. */
const VERSION='minha-voz-publicavel-1.1.0';
const SHELL=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./data/vocabulary.json','./icons/icon-192.png','./icons/icon-512.png','./icons/favicon.svg'];
const WORDS=['sim','nao','quero','nao-quero','mais','de-novo','acabou','parar','ajuda','espera','outro','eu','voce','isso','olha','agua','preciso-de-ajuda'];
const AUDIO=WORDS.flatMap(word=>['mp3','ogg'].map(ext=>'./audio/'+word+'.'+ext));
self.addEventListener('install',e=>e.waitUntil(caches.open(VERSION).then(async cache=>{await cache.addAll(SHELL);await Promise.all(AUDIO.map(path=>cache.add(path).catch(()=>{})));await self.skipWaiting()})));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(x=>x!==VERSION).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(resp=>{if(resp.ok){const c=resp.clone();caches.open(VERSION).then(cache=>cache.put(e.request,c))}return resp}).catch(()=>caches.match('./index.html'))))});
