MINHA VOZ – CAA | SITE ESTÁTICO PUBLICÁVEL
=========================================

ESTE ZIP É PUBLICÁVEL SEM NODE.JS E SEM COMPILAÇÃO.
Contém index.html, app.js, styles.css, manifest.webmanifest, sw.js, áudio e imagens.

PUBLICAR (mais simples):
1. Acesse https://app.netlify.com/drop (Netlify Drop).
2. Extraia o ZIP e arraste A PASTA EXTRAÍDA para a área de publicação.
3. Abra o endereço HTTPS fornecido; utilize "Experimentar sem cadastro".
4. Instale como app pelo menu do navegador (Adicionar à tela inicial).

OUTRAS HOSPEDAGENS:
- Cloudflare Pages: projeto com upload direto, publicando o conteúdo desta pasta.
- Hospedagem própria Apache/Nginx: copie TODOS os arquivos e pastas para o diretório público HTTPS.
- Não abra index.html por file://; o service worker requer HTTPS (ou localhost).

ESTADO DA EDIÇÃO
- Esta edição estática executa a demo local com 146 cartões, frases, fala, rotinas,
  jogos simples, ajuda, preferências, fotos de cartões, PIN local, relatórios via
  impressão em PDF, gravação opcional e armazenamento no próprio dispositivo.
- Não possui backend. Não disponibiliza login real, separação entre contas, RLS,
  sincronização, compartilhamento com profissionais ou backup na nuvem.
- Não utilize para armazenar dados sensíveis de crianças em dispositivos públicos.
- A voz sintetizada depende das vozes instaladas no dispositivo. Gravações
  empacotadas dos 15 termos essenciais, "água" e "preciso de ajuda" funcionam offline.
- Nunca copie para uma pasta pública arquivos .env, credenciais ou senhas.

PARA OPERAR COM CONTAS E BANCO NA NUVEM:
Use o ZIP separado "Minha_Voz_CAA_FONTE_VERCEL.zip", configure Supabase,
execute a migração SQL e publique via Git + Vercel (constrói o projeto React).
Antes de atender usuários reais, valide login, RLS, privacidade e testes em dispositivos.

ATUALIZAÇÃO 1.1.0 — TEMA ESCURO E ACESSO AO PAINEL ADULTO
- Toque em "Lua/Escuro" ou "Sol/Claro" no cabeçalho para alternar. Preferência
  também disponível no Painel > Configurações > Tema da interface.
- Escolhas: automático pelo aparelho, claro ou escuro. Alto contraste e baixa
  estimulação podem ser utilizados juntamente com o tema escuro.
- Para entrar no painel adulto, basta TOCAR uma vez em "Painel" no topo ou
  "Sou responsável" na apresentação. Na primeira vez, crie PIN de 4 a 8 dígitos.
  Nas próximas vezes, informe esse mesmo PIN.
- Já possui site publicado no Netlify? Abra o site no painel Netlify > Deploys e
  faça novo deploy manual arrastando a PASTA EXTRAÍDA para a área indicada.
  Evite criar outro site se deseja manter o mesmo endereço.
- O ZIP não apaga os dados existentes. Não use os botões de exclusão do painel.
- Para ver a atualização em um PWA já instalado, feche e abra o aplicativo;
  se necessário atualize a página no navegador conectado à internet.
- O PIN LOCAL limita o acesso por toque mas não é autenticação de servidor.
